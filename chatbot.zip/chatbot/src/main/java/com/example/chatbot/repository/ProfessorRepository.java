package com.example.chatbot.repository;

import com.example.chatbot.model.Professor;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProfessorRepository extends MongoRepository<Professor, String> {}
