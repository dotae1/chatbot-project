package com.example.chatbot.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


@FeignClient(name = "clovaChatbotClient", url = "https://clovachatbot.ncloud.com/api/chatbot/messenger/v1/14002/1296bfb42b244aa5811e4098497329f3845ca6a3715c1da844d1999acc5cdfdd")
public interface ClovaChatbotClient {
    @PostMapping("/v2/dialogs")
    String sendMessage(@RequestHeader("hhV1MvLwvkdCfvPbR9Up") String apiKey,
                       @RequestHeader("y2t7cxrJiWYXneBQOImWQfWxrrb3Q4LVVs7m3RHU") String secretKey,
                       @RequestBody String message);
}
