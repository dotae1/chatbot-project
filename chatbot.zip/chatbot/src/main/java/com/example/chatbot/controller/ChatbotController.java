// UniversityController.java
package com.example.chatbot.controller;

import com.example.chatbot.model.Department;
import com.example.chatbot.model.Professor;
import com.example.chatbot.service.ChatbotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ChatbotController {

    private final ChatbotService chatbotService;

    public ChatbotController(ChatbotService chatbotService) {
        this.chatbotService = chatbotService;
    }

    // 학과 저장
    @PostMapping("/departments")
    public ResponseEntity<Department> createDepartment(@RequestBody Department department) {
        Department savedDepartment = chatbotService.saveDepartment(department);
        return ResponseEntity.ok(savedDepartment);
    }

    // 교수 저장
    @PostMapping("/professors")
    public ResponseEntity<Professor> createProfessor(@RequestBody Professor professor) {
        Professor savedProfessor = chatbotService.saveProfessor(professor);
        return ResponseEntity.ok(savedProfessor);
    }


    // 학과 조회
    @GetMapping("/departments/{id}")
    public ResponseEntity<Department> getDepartment(@PathVariable String id) {
        Department department = chatbotService.getDepartment(id);
        return ResponseEntity.ok(department);
    }

    // 교수 조회
    @GetMapping("/professors/{id}")
    public ResponseEntity<Professor> getProfessor(@PathVariable String id) {
        Professor professor = chatbotService.getProfessor(id);
        return ResponseEntity.ok(professor);
    }

    // 전체 학과 조회
    @GetMapping("/departments")
    public ResponseEntity<List<Department>> getAllDepartments() {
        List<Department> departments = chatbotService.getAllDepartments();
        return ResponseEntity.ok(departments);
    }

    // 전체 교수 조회
    @GetMapping("/professors")
    public ResponseEntity<List<Professor>> getAllProfessors() {
        List<Professor> professors = chatbotService.getAllProfessors();
        return ResponseEntity.ok(professors);
    }

}
