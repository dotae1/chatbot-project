package com.example.chatbot.service;

import com.example.chatbot.config.ClovaChatbotClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public final class ClovaChatService {

    private final ClovaChatbotClient clovaChatbotClient;

    @Value("${hhV1MvLwvkdCfvPbR9Up}")
    private String apiKeyId;

    @Value("${cy2t7cxrJiWYXneBQOImWQfWxrrb3Q4LVVs7m3RHU}")
    private String secretKey;

    public ClovaChatService(ClovaChatbotClient clovaChatbotClient) {
        this.clovaChatbotClient = clovaChatbotClient;
    }

    public String getResponse(String message) {
        return clovaChatbotClient.sendMessage(apiKeyId, secretKey, message);
    }
}
