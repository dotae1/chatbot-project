// Department.java
package com.example.chatbot.model;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Setter
@Getter
@Document(collection = "departments")
public class Department {
    // Setter for id
    // Getter for id
    @Id
    private String id;
    // Setter for name
    // Getter for name
    private String name;
    // Setter for description
    // Getter for description
    private String description;

}

