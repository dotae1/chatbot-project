package com.example.chatbot.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "professors")
public class Professor {
    @Id
    private String id;
    private String name;
    private String department;
    private String email;

    // getters and setters
}