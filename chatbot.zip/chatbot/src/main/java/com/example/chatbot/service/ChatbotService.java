package com.example.chatbot.service;

import com.example.chatbot.model.Department;
import com.example.chatbot.model.Professor;
import com.example.chatbot.repository.DepartmentRepository;
import com.example.chatbot.repository.ProfessorRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ChatbotService {




    private final DepartmentRepository departmentRepository;


    private final ProfessorRepository professorRepository;

    public ChatbotService(DepartmentRepository departmentRepository, ProfessorRepository professorRepository) {
        this.departmentRepository = departmentRepository;
        this.professorRepository = professorRepository;
    }


    // 학과 저장
    public Department saveDepartment(Department department) {
        return departmentRepository.save(department);
    }

    // 교수 저장
    public Professor saveProfessor(Professor professor) {
        return professorRepository.save(professor);
    }

    // 학과 조회
    public Department getDepartment(String departmentId) {
        if (departmentId == null) {
            throw new IllegalArgumentException("The given id must not be null");
        }
        Optional<Department> department = departmentRepository.findById(departmentId);
        return department.orElse(null);
    }
    // 교수 조회
    public Professor getProfessor(String id) {
        return professorRepository.findById(id).orElse(null);
    }

    // 전체 학과 조회
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    // 전체 교수 조회
    public List<Professor> getAllProfessors() {
        return professorRepository.findAll();
    }

}