package com.example.chatbot.controller;

//import com.example.chatbot.model.ChatMessage;
import com.example.chatbot.model.Department;
import com.example.chatbot.service.ChatbotService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.messaging.handler.annotation.MessageMapping;
//import org.springframework.messaging.handler.annotation.SendTo;
//import org.springframework.stereotype.Controller;




import com.example.chatbot.model.ChatMessage;
import com.example.chatbot.service.ClovaChatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;


@Controller
public class WebSocketChatController {

    @Autowired
    private ClovaChatService clovaChatService;

    @MessageMapping("/chat")
    @SendTo("/topic/messages")
    public ChatMessage handleChatMessage(ChatMessage message) {
        String response = clovaChatService.getResponse(message.getContent());
        message.setContent(response);
        return message;
    }
}


